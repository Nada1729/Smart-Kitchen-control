
  # Smart Kitchen Control Interface

  This is a code bundle for Smart Kitchen Control Interface. The original project is available at https://www.figma.com/design/9XPWqJeqtizCDVsZ11XdNL/Smart-Kitchen-Control-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  