import React from 'react';
import { SmartKitchenMobileApp } from './components/SmartKitchenMobileApp';

export default function App() {
  return <SmartKitchenMobileApp />;
}